﻿Imports System.IO
Imports System.Xml

Public Class IHIWConvertor

    Private _File As Byte()
    Private _Manufacturer As String
    Private _xmlFile As Byte()

    Public Sub New(File As Byte())

        _File = File

    End Sub

    Public Property Manufacturer As String
        Get
            Return _Manufacturer
        End Get
        Set(value As String)
            _Manufacturer = value
        End Set
    End Property

    Public ReadOnly Property xmlFile As Byte()
        Get
            Return _xmlFile
        End Get
    End Property
    ''' <summary>
    ''' Determines the manufacturer of the input file.
    ''' The manufacturer can be Immucor or OneLambda.
    ''' Immucor provides a file delimited with ",".
    ''' OneLambda provides a file delimited with ";".
    ''' In order to determine the manufacturer all columns must be present.
    ''' If no manufacturer can be determined the manufacturer string will be empty.
    ''' </summary>
    Public Sub DetermineManufacturer()

        Try

            _Manufacturer = String.Empty
            ' 
            ' OneLambda mapping
            ' 
            Dim stream As New MemoryStream(_File)
            stream.Position = 0
            Dim OLReader As FileIO.TextFieldParser = New FileIO.TextFieldParser(stream)
            OLReader.TextFieldType = FileIO.FieldType.Delimited
            OLReader.SetDelimiters(";")
            Dim currentRow As String()
            currentRow = OLReader.ReadFields()
            Dim PatientID, SampleIDName, RunDate, CatalogID, BeadID, Specificity, RawData, NC2BeadID, PC2BeadID, Rxn As Integer
            PatientID = -1
            SampleIDName = -1
            RunDate = -1
            CatalogID = -1
            BeadID = -1
            Specificity = -1
            RawData = -1
            NC2BeadID = -1
            PC2BeadID = -1
            Rxn = -1
            '
            ' Determine where the columns are
            '
            For i As Integer = 0 To currentRow.Length - 1
                Select Case currentRow(i)
                    Case "PatientID"
                        PatientID = i
                    Case "SampleIDName"
                        SampleIDName = i
                    Case "RunDate"
                        RunDate = i
                    Case "CatalogID"
                        CatalogID = i
                    Case "BeadID"
                        BeadID = i
                    Case "Specificity"
                        Specificity = i
                    Case "RawData"
                        RawData = i
                    Case "NC2BeadID"
                        NC2BeadID = i
                    Case "PC2BeadID"
                        PC2BeadID = i
                    Case "Rxn"
                        Rxn = i
                End Select
            Next
            '
            ' Immucor mapping
            ' 
            stream.Position = 0
            Dim IMReader As FileIO.TextFieldParser = New FileIO.TextFieldParser(stream)
            IMReader.TextFieldType = FileIO.FieldType.Delimited
            IMReader.SetDelimiters(",")
            Dim Sample_ID, Patient_Name, Lot_ID, Run_Date, Allele, Raw_Value, Assignment As Integer

            Sample_ID = -1
            Patient_Name = -1
            Lot_ID = -1
            Run_Date = -1
            Allele = -1
            Raw_Value = -1
            Assignment = -1
            Try
                currentRow = IMReader.ReadFields()
            Catch ex As Exception
                ' Do nothing, it is not possible to read the file with this delimiter.
            Finally
                '
                ' Determine where the columns are
                '
                For i As Integer = 0 To currentRow.Length - 1
                    Select Case currentRow(i)
                        Case "Sample ID"
                            Sample_ID = i
                        Case "Patient Name"
                            Patient_Name = i
                        Case "Lot ID"
                            Lot_ID = i
                        Case "Run Date"
                            Run_Date = i
                        Case "Allele"
                            Allele = i
                        Case "Raw Value"
                            Raw_Value = i
                        Case "Assignment"                            ' Uitkomst: Positive, Negative of weak
                            Assignment = i
                    End Select
                Next

                IMReader.Close()
                OLReader.Close()

                If PatientID > -1 And SampleIDName > -1 And RunDate > -1 And CatalogID > -1 And BeadID > -1 And Specificity > -1 And RawData > -1 And NC2BeadID > -1 And PC2BeadID > -1 And Rxn > -1 Then
                    _Manufacturer = "OneLambda" ' HLA Fusion, One Lambda, Sanbio
                ElseIf Sample_ID > -1 And Patient_Name > -1 And Lot_ID > -1 And Run_Date > -1 And Allele > -1 And Raw_Value > -1 And Assignment > -1 Then
                    _Manufacturer = "Immucor"   ' MatchIt, Lifecodes
                End If
            End Try
        Catch ex As Exception

        End Try

    End Sub

    Public Sub ProcessOneLambda(Center As String)

        Dim SampleID As String

        Dim stream As New MemoryStream(_File)
        Dim Reader As FileIO.TextFieldParser = New FileIO.TextFieldParser(stream)
        Reader.TextFieldType = FileIO.FieldType.Delimited
        Reader.SetDelimiters(";")
        Dim currentRow As String()
        currentRow = Reader.ReadFields()
        Dim PatientID, SampleIDName, RunDate, CatalogID, BeadID, Specificity, RawData, NC2BeadID, PC2BeadID, Rxn As Integer
        Dim NegMFI, PosMFI As Integer
        '
        ' Determine where the columns are
        '
        For i As Integer = 0 To currentRow.Length - 1
            Select Case currentRow(i)
                Case "PatientID"
                    PatientID = i
                Case "SampleIDName"
                    SampleIDName = i
                Case "RunDate"
                    RunDate = i
                Case "CatalogID"
                    CatalogID = i
                Case "BeadID"
                    BeadID = i
                Case "Specificity"
                    Specificity = i
                Case "RawData"
                    RawData = i
                Case "NC2BeadID"
                    NC2BeadID = i
                Case "PC2BeadID"
                    PC2BeadID = i
                Case "Rxn"
                    Rxn = i
            End Select
        Next

        currentRow = Reader.ReadFields()
        SampleID = currentRow(SampleIDName)

        Dim xmlStream As New MemoryStream()
        Using xmlBuilder As XmlWriter = XmlWriter.Create(xmlStream)
            xmlBuilder.WriteStartDocument()
            xmlBuilder.WriteStartElement("haml")
            While Not Reader.EndOfData

                xmlBuilder.WriteStartElement("patient-antibody-assessment")
                xmlBuilder.WriteElementString("sampleID", SampleID)
                xmlBuilder.WriteElementString("patientID", currentRow(PatientID))
                xmlBuilder.WriteElementString("reporting-centerID", Center)
                xmlBuilder.WriteElementString("sample-test-datetime", currentRow(RunDate))

                xmlBuilder.WriteStartElement("solid-phase-panel")
                xmlBuilder.WriteElementString("kit-manufacturer", _Manufacturer)
                xmlBuilder.WriteElementString("lot", currentRow(CatalogID))

                While Not Reader.EndOfData AndAlso SampleID = currentRow(SampleIDName)

                    Dim Specs As String() = currentRow(Specificity).Split(",")
                    Dim Raw As Integer = currentRow(RawData)
                    If currentRow(BeadID) = currentRow(NC2BeadID) Then
                        NegMFI = Raw
                    End If
                    If currentRow(BeadID) = currentRow(PC2BeadID) Then
                        PosMFI = Raw
                    End If
                    For Each SingleSpec As String In Specs
                        If SingleSpec <> "-" Then
                            xmlBuilder.WriteStartElement("bead")
                            xmlBuilder.WriteElementString("HLA-allele-specificity", SingleSpec)
                            xmlBuilder.WriteElementString("raw-MFI", Raw)
                            xmlBuilder.WriteElementString("Ranking", currentRow(Rxn))
                            xmlBuilder.WriteEndElement() ' Bead
                        End If
                    Next

                    currentRow = Reader.ReadFields()

                End While

                xmlBuilder.WriteEndElement() ' solid-phase-panel

                xmlBuilder.WriteElementString("negative-control-MFI", NegMFI)
                xmlBuilder.WriteElementString("positive-control-MFI", PosMFI)

                xmlBuilder.WriteEndElement() ' patient-antibody-assessment

                If Not Reader.EndOfData Then
                    SampleID = currentRow(SampleIDName) ' Next sample
                End If

            End While

            xmlBuilder.WriteEndElement() ' haml
            xmlBuilder.WriteEndDocument()

        End Using
        '
        ' Put the stream into the _xmlFile variable
        '
        _xmlFile = xmlStream.ToArray

    End Sub


    Public Sub ProcessImmucor(Center As String)

        Dim SampleID As String

        Dim stream As New MemoryStream(_File)
        Dim Reader As FileIO.TextFieldParser = New FileIO.TextFieldParser(stream)
        Reader.TextFieldType = FileIO.FieldType.Delimited
        Reader.SetDelimiters(",")
        Dim currentRow As String()
        currentRow = Reader.ReadFields()
        Dim Sample_ID, Patient_Name, Lot_ID, Run_Date, Allele, Raw_Value, Assignment As Integer
        Dim NegMFI, PosMFI As Integer
        '
        ' Determine where the columns are
        '
        For i As Integer = 0 To currentRow.Length - 1
            Select Case currentRow(i)
                Case "Sample ID"
                    Sample_ID = i
                Case "Patient Name"                         ' Temporay, waiting for a proper patient ID
                    Patient_Name = i
                Case "Lot ID"
                    Lot_ID = i
                Case "Run Date"
                    Run_Date = i
                Case "Allele"
                    Allele = i
                Case "Raw Value"
                    Raw_Value = i
                Case "Assignment"                           ' Positive, Negative of weak
                    Assignment = i
            End Select
        Next

        currentRow = Reader.ReadFields()
        SampleID = currentRow(Sample_ID)

        Dim xmlStream As New MemoryStream()
        Using xmlBuilder As XmlWriter = XmlWriter.Create(xmlStream)
            xmlBuilder.WriteStartDocument()
            xmlBuilder.WriteStartElement("haml")
            While Not Reader.EndOfData

                xmlBuilder.WriteStartElement("patient-antibody-assessment")
                xmlBuilder.WriteElementString("sampleID", SampleID)
                xmlBuilder.WriteElementString("patientID", currentRow(Patient_Name))
                xmlBuilder.WriteElementString("reporting-centerID", Center)
                xmlBuilder.WriteElementString("sample-test-datetime", currentRow(Run_Date))

                xmlBuilder.WriteStartElement("solid-phase-panel")
                xmlBuilder.WriteElementString("kit-manufacturer", _Manufacturer)
                xmlBuilder.WriteElementString("lot", currentRow(Lot_ID))

                While Not Reader.EndOfData AndAlso SampleID = currentRow(Sample_ID)

                    xmlBuilder.WriteStartElement("bead")
                    xmlBuilder.WriteElementString("HLA-allele-specificity", currentRow(Allele))
                    xmlBuilder.WriteElementString("raw-MFI", currentRow(Raw_Value))
                    Dim Ranking As Integer
                    Select Case currentRow(Assignment)
                        Case "Positive"
                            Ranking = 8
                        Case "Weak"
                            Ranking = 6
                        Case "Negative"
                            Ranking = 2
                        Case Else
                            Ranking = 2
                    End Select
                    xmlBuilder.WriteElementString("Ranking", Ranking)
                    ' Temporary solution for missing Pos/Neg:
                    If currentRow(Raw_Value) < NegMFI Then
                        NegMFI = currentRow(Raw_Value)
                    End If
                    If currentRow(Raw_Value) > PosMFI Then
                        PosMFI = currentRow(Raw_Value)
                    End If
                    xmlBuilder.WriteEndElement() ' Bead

                    currentRow = Reader.ReadFields()

                End While

                xmlBuilder.WriteEndElement() ' solid-phase-panel
                ' Temporary solution for missing Pos/Neg:
                xmlBuilder.WriteElementString("negative-control-MFI", NegMFI)
                xmlBuilder.WriteElementString("positive-control-MFI", PosMFI)

                xmlBuilder.WriteEndElement() ' patient-antibody-assessment

                If Not Reader.EndOfData Then
                    SampleID = currentRow(Sample_ID) ' Next sample
                End If

            End While

            xmlBuilder.WriteEndElement() ' haml
            xmlBuilder.WriteEndDocument()

        End Using
        '
        ' Put the stream into the _xmlFile variable
        '
        _xmlFile = xmlStream.ToArray

    End Sub

End Class
