﻿Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.ComponentModel
Imports System.IO

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
' <System.Web.Script.Services.ScriptService()> _
<System.Web.Services.WebService(Namespace:="http://ETRL.ORG/")>
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)>
Public Class Convertor
    Inherits System.Web.Services.WebService

    Public Class ConvertorInput
        Public Center As String
        Public Filename As String
        Public File As Byte()
    End Class
    Public Class ConvertorOuput
        Public File As Byte()
        Public ErrorMessage As String
    End Class

    <WebMethod()>
    Public Function Convert(Request As ConvertorInput) As ConvertorOuput

        Dim Response As ConvertorOuput = New ConvertorOuput

        Try

            If String.IsNullOrEmpty(Request.Center) Then
                Request.Center = "Not supplied"
            End If

            Dim Manufacturer As String = String.Empty
            Dim Convertor As New IHIWConvertor(Request.File)
            Convertor.DetermineManufacturer()

            If Convertor.Manufacturer = String.Empty Then
                Response.ErrorMessage = "Please only supply valid OneLambda- or Immucor files."
                Return Response
            End If

            If Convertor.Manufacturer = "Immucor" Then
                Convertor.ProcessImmucor(Request.Center)
            Else
                Convertor.ProcessOneLambda(Request.Center)
            End If

            Response.File = Convertor.xmlFile

        Catch ex As Exception
            Response.ErrorMessage = ex.Message
        End Try

        Return Response

    End Function

End Class