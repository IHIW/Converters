﻿Imports System.IO
Imports System.Xml
Imports System.Xml.Schema
Public Class Form1

    Private _ValidationErrors As String
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnClass.Click

        Dim Bestand As String = ""
        Dim result As DialogResult = System.Windows.Forms.DialogResult.OK
        Dim ErrorMessage As String = String.Empty

        ofdOpenFile.FileName = ""
        ofdOpenFile.Filter = "CSV Files|*.csv|All Files|*.*"
        result = ofdOpenFile.ShowDialog()
        If result = DialogResult.OK Then
            Bestand = ofdOpenFile.FileName
            Dim FileArray As Byte() = File.ReadAllBytes(Bestand)

            Dim Manufacturer As String = String.Empty

            Dim Convertor As New IHIWS18Convertor.IHIWConvertor(FileArray)
            Convertor.DetermineManufacturer()

            If Convertor.Manufacturer = String.Empty Then
                ErrorMessage = "Please only supply valid OneLambda- or Immucor files."
            Else
                If Convertor.Manufacturer = "Immucor" Then
                    Convertor.ProcessImmucor("LUMC")
                Else
                    Convertor.ProcessOneLambda("LUMC")
                End If
                Dim fs As New FileStream("C:\HAML\" & Path.GetFileName(Bestand).Replace(".csv", ".xml"), FileMode.Create)
                fs.Write(Convertor.xmlFile, 0, Convertor.xmlFile.Length)
                fs.Flush()
                fs.Close()
            End If

            If Not String.IsNullOrEmpty(ErrorMessage) Then
                MsgBox(ErrorMessage)
            Else
                MsgBox("OK")
            End If

        End If

    End Sub

    Private Sub btnWebservice_Click(sender As Object, e As EventArgs) Handles btnWebservice.Click

        Dim Bestand As String = ""
        Dim result As DialogResult = System.Windows.Forms.DialogResult.OK

        ofdOpenFile.FileName = ""
        ofdOpenFile.Filter = "CSV Files|*.csv|All Files|*.*"
        result = ofdOpenFile.ShowDialog()
        If result = DialogResult.OK Then
            Bestand = ofdOpenFile.FileName
            Dim FileArray As Byte() = File.ReadAllBytes(Bestand)
            Dim Request As New svcConvertor.ConvertorInput
            Request.File = FileArray
            Request.Filename = Path.GetFileName(Bestand)
            Request.Center = "LUMC"
            Dim response As New svcConvertor.ConvertorOuput

            Dim service As New svcConvertor.ConvertorSoapClient
            response = service.Convert(Request)

            If String.IsNullOrEmpty(response.ErrorMessage) Then

                Dim fs As New FileStream("C:\HAML\" & Request.Filename.Replace(".csv", ".xml"), FileMode.Create)
                fs.Write(response.File, 0, response.File.Length)
                fs.Flush()
                fs.Close()

            End If

            If Not String.IsNullOrEmpty(response.ErrorMessage) Then
                MsgBox(response.ErrorMessage)
            Else
                MsgBox("OK")
            End If

        End If

    End Sub


End Class
